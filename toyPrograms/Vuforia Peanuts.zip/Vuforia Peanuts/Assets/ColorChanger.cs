﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ColorChanger : MonoBehaviour
{
    public GameObject ui;

    void Start()
    {
        ui.SetActive(false);
    }
    void OnMouseOver()
    {
        if (Input.GetMouseButtonDown(0))
        {
            Debug.Log(ui.activeSelf);
            if(ui.activeSelf == true)
            {
                ui.SetActive(false);
            }
            else
            {
                ui.SetActive(true);
            }
        }
    }
}
