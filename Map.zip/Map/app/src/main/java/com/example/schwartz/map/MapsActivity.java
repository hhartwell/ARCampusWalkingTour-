package com.example.schwartz.map;

import android.support.v4.app.FragmentActivity;
import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;


        LatLng desmetHall = new LatLng(47.6679039, -117.4011365);
        mMap.addMarker(new MarkerOptions().position(desmetHall).title("Desmet Hall"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(desmetHall));

        LatLng dillonHall = new LatLng(47.6692158, -117.4008781);
        mMap.addMarker(new MarkerOptions().position(dillonHall).title("Dillon Hall"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(dillonHall));

        LatLng gollerHall = new LatLng(47.66932910000001, -117.40063359999999);
        mMap.addMarker(new MarkerOptions().position(gollerHall).title("Goller Hall"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(gollerHall));

        LatLng corkeryApartments = new LatLng(47.6700233, -117.40013950000002);
        mMap.addMarker(new MarkerOptions().position(corkeryApartments).title("Corkery Apartments"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(corkeryApartments));

        LatLng kennedyApartments = new LatLng(47.66893289999999, -117.40867839999999);
        mMap.addMarker(new MarkerOptions().position(kennedyApartments).title("Kennedy Apartments"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(kennedyApartments));

        LatLng dooleyHall = new LatLng(47.6691861, -117.40541589999998);
        mMap.addMarker(new MarkerOptions().position(dooleyHall).title("Dooley Hall"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(dooleyHall));

        LatLng coughlinHall = new LatLng(47.66489060000001, -117.3970516);
        mMap.addMarker(new MarkerOptions().position(coughlinHall).title("Coughlin Hall"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(coughlinHall));
    }
}
